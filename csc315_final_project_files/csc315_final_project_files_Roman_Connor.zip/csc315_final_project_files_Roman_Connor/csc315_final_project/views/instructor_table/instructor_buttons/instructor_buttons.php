<div class="col-sm-3" style="line-height:0;padding:0;font-weight:bolder;color: gold;">CONTROLS</div>
<!--SHOW ALL INSTRUCTORS BUTTON ############################################################ -->
<button class="button btn-warning btn-primary-spacing height" type="submit" id="show_all_instructors"
        name="show_all_instructors">
    <span style="font-size: 15px; font-weight: bold">SHOW ALL INSTRUCTORS</span>
</button>

<!--FIND INSTRUCTORS BUTTON ############################################################ -->
<button class="button btn-warning btn-primary-spacing height" type="submit" id="find_instructors"
        name="find_instructors">
    <span style="font-size: 15px; font-weight: bold">FIND INSTRUCTORS</span>
</button>

<!--UPDATE INSTRUCTORS BUTTON ############################################################ -->
<button class="button btn-warning btn-primary-spacing height" type="submit" id="i_update_instructors"
        name="update_instructors">
    <span style="font-size: 15px; font-weight: bold">UPDATE INSTRUCTORS</span>
</button>

<!--INSERT INSTRUCTORS BUTTON ############################################################ -->
<button class="button btn-warning btn-primary-spacing height" type="submit" id="i_add_instructors"
        name="add_instructors">
    <span style="font-size: 15px; font-weight: bold">ADD INSTRUCTORS</span>
</button>

<!--DELETE INSTRUCTORS BUTTON ############################################################ -->
<button class="button btn-warning btn-primary-spacing height" type="submit" id="i_delete_instructors"
        name="delete_instructors">
    <span style="font-size: 15px; font-weight: bold">DELETE INSTRUCTORS</span>
</button>

<!-- ####### DEPARTMENT PAGE #####################################################################################################-->
<br><div class="col-sm-3" style="line-height:0;padding:0;font-weight:bolder;color: gold;">NAVIGATION</div>
<!-- VIEW STUDENT ############################################################################## -->
<button class="button btn-warning height" type="submit" id="student_page" name="student_page">
    <span style="font-size: 15px; font-weight: bold">STUDENTS</span>
</button>
<!-- VIEW GRADES BUTTON ############################################################ -->
<button class="button btn-warning btn-primary-spacing height" type="submit" id="view_grades"
        name="view_grades">
    <span style="font-size: 15px; font-weight: bold">GRADES</span>
</button>

<!-- VIEW COURSE BUTTONS ############################################################ -->
<button class="button btn-warning btn-primary-spacing height" type="submit" id="view_course"
        name="view_classes">
    <span style="font-size: 15px; font-weight: bold">COURSES</span>
</button>
<!-- DEPARTMENT BUTTON ############################################################ -->
<button class="button btn-warning btn-primary-spacing height" type="submit" id="department"
        name="department">
    <span style="font-size: 15px; font-weight: bold">DEPARTMENTS</span>
</button>

<!-- VIEW FINANCIAL AID ############################################################ -->
<button class="button btn-warning btn-primary-spacing height" type="submit" id="fin_aid">
    <span style="font-size: 15px; font-weight: bold">FINANCIAL AID</span>
</button>

<!-- VIEW SEMESTER ############################################################ -->
<button class="button btn-warning btn-primary-spacing height" type="submit" id="view_semester"
        name="view_semester">
    <span style="font-size: 15px; font-weight: bold">SEMESTERS</span>
</button>
<script><?php require($_SERVER['DOCUMENT_ROOT'] . '/csc315_final_project/js/instructor_page.js'); ?></script>
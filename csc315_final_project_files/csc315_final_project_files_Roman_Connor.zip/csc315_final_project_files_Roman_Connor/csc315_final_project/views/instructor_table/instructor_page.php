<!-- FIRST NAME ############################################################################## -->
<div class="row gap-4 mt-4">
    <div class="col-sm-4 fw-bold">FIRST NAME:</div>
    <div class="col-sm-6"><input id="firstName" value="" class="resp-text" type="text"></div>
</div>

<!-- LAST NAME ############################################################################## -->
<div class="row gap-4 mt-4">
    <div class="col-sm-4 fw-bolder">LAST NAME:</div>
    <div class="col-sm-6"><input id="lastName" class="resp-text" type="text"></div>
</div>

<!-- RANK ############################################################################## -->
<div class="row gap-4 mt-4">
    <div class="col-sm-4 fw-bolder">RANK:</div>
    <div class="col-sm-6"><input id="rank" name="rank" class="resp-text" type="text"></div>
</div>

<!-- INSTRUCTOR OFFICE ############################################################################## -->
<div class="row gap-4 mt-4">
    <div class="col-sm-4 fw-bolder">INSTRUCTOR OFFICE:</div>
    <div class="col-sm-6"><input id="office" name="office" class="resp-text" type="text"></div>
</div>

<!-- INSTRUCTOR DEPARTMENT ############################################################################## -->
<div class="row gap-4 mt-4">
    <div class="col-sm-4 fw-bolder">INSTRUCTOR DEPARTMENT:</div>
    <div class="col-sm-6"><input id="dept_name" name="dept_name" class="resp-text" type="text"
                                 disabled="disabled"></div>
</div>






<!-- SEMESTER START DATE ############################################################################## -->
<div class="row gap-4 mt-4">
    <div class="col-sm-3 fw-bold">SEMESTER START DATE:</div>
    <div class="col-sm-6"><input id="semester_start" class="resp-text" type="text"></div>
</div>

<!-- SEMESTER END DATE ############################################################################## -->
<div class="row gap-4 mt-4">
    <div class="col-sm-3 fw-bold">SEMESTER END DATE:</div>
    <div class="col-sm-6"><input id="semester_end" class="resp-text" type="text"></div>
</div>

<!-- SEMESTER END DATE ############################################################################## -->
<div class="row gap-4 mt-4">
    <div class="col-sm-3 fw-bold">SPRING / SUMMER / FALL:</div>
    <div class="col-sm-6"><input id="semester_time" class="resp-text" type="text"></div>
</div>
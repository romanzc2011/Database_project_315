<div class="container-fluid" id="cover_page">
    <!-- SEARCH BAR ROW ################################################################## -->
    <div class="row between-xs" id="index_header">
        <div class="col-sm-12">
                        <span class="lg-font bf-left">
                            University Registration System
                        </span>

            <span class="input-rt">SEMESTER ID:<input style="border-radius: 0.5em;" type="text" name="semesterID"
                                                    id="semesterID" class="input-rt">
            </span>
        </div>
    </div>
</div>
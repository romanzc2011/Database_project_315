
<!-- COURSE NAME ############################################################################## -->
<div class="row gap-4 mt-4">
    <div class="col-sm-3 fw-bold">COURSE NAME:</div>
    <div class="col-sm-6"><input id="courseName" name="courseName" class="resp-text" type="text"></div>
</div>

<!-- CREDIT HOURS ############################################################################## -->
<div class="row gap-4 mt-4">
    <div class="col-sm-3 fw-bold">CREDIT HOURS:</div>
    <div class="col-sm-6"><input id="creditHrs" name="creditHrs" class="resp-text" type="text"></div>
</div>

<!-- INSTRUCTOR ID ############################################################################## -->
<div class="row gap-4 mt-4">
    <div class="col-sm-3 fw-bold">INSTRUCTOR ID:</div>
    <div class="col-sm-6"><input id="instructor_id" name="instructor_id" class="resp-text" type="text"></div>
</div>

<!-- INSTRUCTOR LAST_NAME ############################################################################## -->
<div class="row gap-4 mt-4">
    <div class="col-sm-3 fw-bold">INSTRUCTOR LASTNAME:</div>
    <div class="col-sm-6"><input id="instructorName" name="instructorName" class="resp-text" type="text" disabled="disabled"></div>
</div>
<!-- FINANCIAL AID SOURCE ############################################################################## -->
<div class="row gap-4 mt-4">
    <div class="col-sm-3 fw-bold">FINANCIAL AID SOURCE:</div>
    <div class="col-sm-6"><input id="finaid_source" class="resp-text" type="text"></div>
</div>

<!-- FINANCIAL AID AMOUNT ############################################################################## -->
<div class="row gap-4 mt-4">
    <div class="col-sm-3 fw-bold">FINANCIAL AID AMOUNT AWARD:</div>
    <div class="col-sm-6"><input id="finaid_amount" class="resp-text" type="text"></div>
</div>

<!-- STUDENT ID ############################################################################## -->
<div class="row gap-4 mt-4">
    <div class="col-sm-3 fw-bold">STUDENT ID:</div>
    <div class="col-sm-6"><input id="student_id" class="resp-text" type="text"></div>
</div>

<!-- FACULTY ID ############################################################################## -->
<div class="row gap-4 mt-4">
    <div class="col-sm-4 fw-bold">FACULTY ID:</div>
    <div class="col-sm-6"><input id="faculty_id" name="faculty_id" class="resp-text" type="text" disabled="disabled"></div>
</div>

<!-- DEPARTMENT ID ############################################################################## -->
<div class="row gap-4 mt-4">
    <div class="col-sm-4 fw-bold">DEPARTMENT ID:</div>
    <div class="col-sm-6"><input id="department_id" name="department_id" class="resp-text" type="text"></div>
</div>

<!-- DEPARTMENT NAME ############################################################################## -->
<div class="row gap-4 mt-4">
    <div class="col-sm-4 fw-bolder">DEPARTMENT NAME:</div>
    <div class="col-sm-6"><input id="department_name" name="department_name" class="resp-text" type="text"></div>
</div>

<!-- INSTRUCTOR ID ############################################################################## -->
<div class="row gap-4 mt-4">
    <div class="col-sm-4 fw-bolder">INSTRUCTOR ID:</div>
    <div class="col-sm-6"><input id="instructor_id" name="instructor_id" class="resp-text" type="text"></div>
</div>

<!-- INSTRUCTOR LASTNAME ############################################################################## -->
<div class="row gap-4 mt-4">
    <div class="col-sm-4 fw-bolder">INSTRUCTOR LASTNAME:</div>
    <div class="col-sm-6"><input id="instructor_lastname" name="instructor_lastname" class="resp-text" type="text" disabled="disabled"></div>
</div>

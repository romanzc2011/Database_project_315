<div class="col-sm-3" style="line-height:0;padding:0;font-weight:bolder;color: gold;">CONTROLS</div>
<!-- SHOW DEPARTMENT BUTTON ############################################################ -->
<button class="button btn-warning btn-primary-spacing height" type="submit" id="show_department"
        name="show_department">
    <span style="font-size: 15px; font-weight: bold">SHOW ALL DEPARTMENT</span>
</button>

<!-- FIND MEMBERS OF DEPARTMENT BUTTON ############################################################ -->
<button class="button btn-warning btn-primary-spacing height" type="submit" id="find_deptStaff"
        name="find_deptStaff">
    <span style="font-size: 15px; font-weight: bold">FIND FACULTY STAFF</span>
</button>

<!-- ADD STAFF TO DEPARTMENT ############################################################ -->
<button class="button btn-warning btn-primary-spacing height" type="submit" id="add_deptStaff"
        name="add_deptStaff">
    <span style="font-size: 15px; font-weight: bold">ADD DEPT. STAFF </span>
</button>

<!-- UPDATE DEPARTMENT ############################################################ -->
<button class="button btn-warning btn-primary-spacing height" type="submit" id="update_dept"
        name="update_dept">
    <span style="font-size: 15px; font-weight: bold">UPDATE DEPARTMENT</span>
</button>

<!-- DELETE DEPARTMENT ############################################################ -->
<button class="button btn-warning btn-primary-spacing height" type="submit" id="delete_deptMember"
        name="delete_deptMember">
    <span style="font-size: 15px; font-weight: bold">DELETE DEPT. MEMBER</span>
</button>

<br><div class="col-sm-3" style="line-height:0;padding:0;font-weight:bolder;color: gold;">NAVIGATION</div>
<!-- VIEW STUDENT ############################################################################## -->
<button class="button btn-warning height" type="submit" id="student_page" name="student_page">
    <span style="font-size: 15px; font-weight: bold">STUDENTS</span>
</button>

<!-- VIEW GRADES BUTTON ############################################################ -->
<button class="button btn-warning btn-primary-spacing height" type="submit" id="view_grades"
        name="view_grades">
    <span style="font-size: 15px; font-weight: bold">GRADES</span>
</button>

<!-- VIEW COURSE BUTTONS ############################################################ -->
<button class="button btn-warning btn-primary-spacing height" type="submit" id="view_course"
        name="view_course">
    <span style="font-size: 15px; font-weight: bold">COURSES</span>
</button>

<!-- VIEW INSTRUCTORS PAGE ############################################################################## -->
<button class="button btn-warning height" type="submit" id="instructors_page" name="instructors_page">
    <span style="font-size: 15px; font-weight: bold">INSTRUCTORS</span>
</button>

<!-- ####### FINANCIAL AID PAGE #####################################################################################################-->
<!-- VIEW FINANCIAL AID ############################################################ -->
<button class="button btn-warning btn-primary-spacing height" type="submit" id="fin_aid"
        name="fin_aid">
    <span style="font-size: 15px; font-weight: bold">FINANCIAL AID</span>
</button>

<!-- VIEW SEMESTER ############################################################ -->
<button class="button btn-warning btn-primary-spacing height" type="submit" id="view_semester"
        name="view_semester">
    <span style="font-size: 15px; font-weight: bold">SEMESTERS</span>
</button>







<script><?php require($_SERVER['DOCUMENT_ROOT'] . '/csc315_final_project/js/department_page.js'); ?></script>
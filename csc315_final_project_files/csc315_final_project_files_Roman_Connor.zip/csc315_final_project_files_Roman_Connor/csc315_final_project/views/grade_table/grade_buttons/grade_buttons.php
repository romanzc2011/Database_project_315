<!-- DISPLAY ALL GRADES BUTTON ############################################################ -->
<div class="col-sm-3" style="line-height:0;padding:0;font-weight:bolder;color: gold;">CONTROLS</div>

<button class="button btn-warning btn-primary-spacing height" type="submit" id="display_all_grades"
        name="display_all_grades">
    <span style="font-size: 15px; font-weight: bold">SHOW ALL GRADES</span>
</button>

<!-- DISPLAY GRADES BUTTON ############################################################ -->
<button class="button btn-warning btn-primary-spacing height" type="submit" id="display_grades"
        name="display_grades">
    <span style="font-size: 15px; font-weight: bold">DISPLAY GRADES</span>
</button>

<!-- INSERT GRADES BUTTON ############################################################ -->
<button class="button btn-warning btn-primary-spacing height" type="submit" id="insert_grades"
        name="insert_grades">
    <span style="font-size: 15px; font-weight: bold">INSERT GRADES</span>
</button>

<!-- UPDATE GRADES BUTTON ############################################################ -->
<button class="button btn-warning btn-primary-spacing height" type="submit" id="update_grades"
        name="update_grades">
    <span style="font-size: 15px; font-weight: bold">UPDATE GRADES</span>
</button>

<!-- DELETE GRADES BUTTON ############################################################ -->
<button class="button btn-warning btn-primary-spacing height" type="submit" id="delete_grades"
        name="delete_grades">
    <span style="font-size: 15px; font-weight: bold">DELETE GRADES</span>
</button>
<br><div class="col-sm-3" style="line-height:0;padding:0;font-weight:bolder;color: gold;">NAVIGATION</div>
<!-- VIEW STUDENT ############################################################################## -->
<button class="button btn-warning height" type="submit" id="student_page" name="student_page">
    <span style="font-size: 15px; font-weight: bold">STUDENTS</span>
</button>

<!-- VIEW COURSE BUTTONS ############################################################ -->
<button class="button btn-warning btn-primary-spacing height" type="submit" id="view_course"
        name="view_course">
    <span style="font-size: 15px; font-weight: bold">COURSES</span>
</button>

<!-- DEPARTMENT BUTTON ############################################################ -->
<button class="button btn-warning btn-primary-spacing height" type="submit" id="view_department"
        name="view_department">
    <span style="font-size: 15px; font-weight: bold">DEPARTMENTS</span>
</button>

<!-- VIEW INSTRUCTOR BUTTONS ############################################################ -->
<button class="button btn-warning btn-primary-spacing height" type="submit" id="view_instructors">
    <span style="font-size: 15px; font-weight: bold">INSTRUCTORS</span>
</button>

<!-- VIEW FINANCIAL AID ############################################################ -->
<button class="button btn-warning btn-primary-spacing height" type="submit" id="view_financial_aid"
        name="view_financial_aid">
    <span style="font-size: 15px; font-weight: bold">FINANCIAL AID</span>
</button>

<!-- VIEW SEMESTER ############################################################ -->
<button class="button btn-warning btn-primary-spacing height" type="submit" id="view_semester"
        name="view_semester">
    <span style="font-size: 15px; font-weight: bold">SEMESTERS</span>
</button>

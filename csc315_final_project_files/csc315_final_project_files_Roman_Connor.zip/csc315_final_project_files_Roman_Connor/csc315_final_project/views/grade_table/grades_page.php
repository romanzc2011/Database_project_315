<div class="row gap-4 mt-4">
    <div class="col-sm-3 fw-bold">STUDENT ID:</div>
    <div class="col-sm-6"><input id="student_id" name="student_id" class="resp-text" type="text"></div>
</div>

<div class="row gap-4 mt-4">
    <div class="col-sm-3 fw-bold">COURSE ID:</div>
    <div class="col-sm-6"><input id="course_id" name="course_id" class="resp-text" type="text"></div>
</div>

<div class="row gap-4 mt-4">
    <div class="col-sm-3 fw-bold">GRADE:</div>
    <div class="col-sm-6"><input id="grade" name="grade" class="resp-text" type="text"></div>
</div>

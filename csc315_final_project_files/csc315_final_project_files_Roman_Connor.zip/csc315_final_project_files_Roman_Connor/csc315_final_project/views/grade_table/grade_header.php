<div class="container-fluid" id="cover_page">
    <!-- SEARCH BAR ROW ################################################################## -->
    <div class="row between-xs" id="index_header">
        <div class="col-sm-12">
                        <span class="lg-font bf-left">
                            University Registration System
                        </span>

            <span class="input-rt">STUDENT ID<input style="border-radius: 0.5em;" type="text" id="studentID" class="input-rt">
            </span>

            <!-- GRADE ID USED FOR UPDATE AND DELETE-->
            <span class="input-rt">GRADE ID<input style="border-radius: 0.5em;" type="text" id="gradeID" class="input-rt">
            </span>
        </div>
    </div>
</div>
<?php

require($_SERVER['DOCUMENT_ROOT'].'/csc315_final_project/views/student_table/student.php');
?>